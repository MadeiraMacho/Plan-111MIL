package practico;

import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class Ejercicio {
    
    public static void main(String[] args) {
     int ancho, largo, resultado;
     int condicional=0,numej; 
     
     
     
    Scanner ejercicios = new Scanner (System.in);
    //MENÚ
 numej = Integer.parseInt(JOptionPane.showInputDialog(null, "--(POR FAVOR ELIJA UNO DE LOS EJERCICIOS A SEGUIR, DIGITANDO SU NÚMERO)--"
 +"\n1.Lote de un terreno \n2. Lectura de dos números \n3. Cantidad de pintura para pintar una pared"
         +"\n4. Intercambio de variables \n5. Perimetro de un cuadrado \n6. Articulos \n7. Ecuación de segundo grado"+
         "\n8. Distancia entre dos puntos en Dtms \n9. Tiempo transcurrido desde el inicio hasta el final de un acontecimiento"+
         "\n10. Aquí se encuentra resuelto los siguientes ejercicios: "
         +"\n  -10. Indicar si un número ingresado es par o impar. " 
         + "\n -11. Leer un número e indicar si este es múltiplo de dos. " 
         +"\n  -12. Leer un número e indicar si el mismo es divisible por tres." 
         + "\n13. Número primo \n14. Número mayor \n15. Número mayor entre tres números ingresado"
         +"16. Cociente entre dos números \n17. Leer dos números, si el primero es el mayor, sumarlos, si no multiplicarlos"
         +"18. Raíz cuadrada de la suma de tres números \n19. Lados de un triangulo \n20.Suma de dos números, es mayor que 730?"
         +"\n21. Perímetro de un Rectangulo \n22. Orden ascendente de 4 números"
         +"\n\nDIGITE EL NÚMERO DEL EJERCICIO ELEJIDO: "));
     
  switch(numej){       
 
      case 1: System.out.println("Ejercicio1: 1.	Si un lote de terreno tiene X metros de frente por Y metros de fondo: \ncalcular e imprimir la cantidad da metros de alambre para cercarlo (X e Y serán leídos al comenzar el programa).");    
  
        System.out.println("Ingresar largo del terreno: ");
        largo = ejercicios.nextInt();

        System.out.println("Ingresar ancho del terreno: ");
        ancho = ejercicios.nextInt(); 

        resultado = (ancho*2)+(largo*2);

          System.out.println("La cantidad de metros de alambre necesario para cercar el terreno es: "+resultado+"m");
         
     System.out.print("-----------------------------------------------------------------------------------------------------------------------------------------------");
    break;
    
      case 2: System.out.println("Ejercicio2: Realizar algoritmo que lea dos números, calculando y escribiendo el valor de su suma, resta, producto y división.");    
    
      int numero1, numero2, producto, suma, resta;
      float division;
    
    System.out.println("Ingresar un número: ");
    numero1 = ejercicios.nextInt();
    
    System.out.println("Ingresar otro número: ");
    numero2 = ejercicios.nextInt();
    
    suma = numero1+numero2;
    resta = numero1-numero2;
    producto = numero1*numero2;
    
    System.out.println("La Suma de estos dos números es: "+suma);
    System.out.println("La Resta de estos dos números es: "+resta);
    System.out.println("El Producto de estos dos números es: "+producto);
    
    if(numero1 ==0 && numero2 ==0 )
        {
            System.out.println("No se peude dividir por Cero"); 
    
            } else {
            division = numero1/numero2;
        System.out.println("La División de estos dos números es: "+division);                
    }
    
          
       System.out.print("-----------------------------------------------------------------------------------------------------------------------------------------------");
    break;
      
      case 3: System.out.println("Ejercicio3: Un pintor sabe que con una pintura determinada puede pintar 3,6 metros cuadrados por cada medio litro. \nSabiendo la altura y el largo de la pared a pintar, informar cuántos litros de pintura utilizará (Altura y Largo en metros)");
    
    int largo1, altura;
    float r, litro;
    
    
    System.out.println("Ingresar largo de la pared en metros: ");
    largo1 = ejercicios.nextInt();
    
    System.out.println("Ingresar altura de la pared en metros: ");
    altura = ejercicios.nextInt();
    
    r = largo1*altura;
    litro = (float) ((r*0.5)/3.6);
     
    System.out.println("La cantidad de pintura que se utilizará para pintar la pared es: "+litro);
  
            
    System.out.println("-----------------------------------------------------------------------------------------------------------------");
    break;
      
      case 4: System.out.println("Ejercicio4: Dadas dos variables numéricas A y B, que el usuario debe teclear, se pide realizar un algoritmo que intercambie los valores de ambas variables \ny muestre cuánto valen al final las dos variables (recuerda la asignación) ");
    
    int a, b, aux=0;
    
    System.out.println("Ingresar número 1: ");
    a = ejercicios.nextInt();
    
    System.out.println("Ingresar número 2: ");
    b = ejercicios.nextInt();
    
    a = aux;
    a = b;
    b = aux;
    
    System.out.println("Los valores intercambiados son: " +"número 1 es = "+a +"Y número 2 es = "+b);
    
   
    System.out.println("-----------------------------------------------------------------------------------------------------------------");
    break;
   
      case 5: System.out.println("Ejercicio5: Ingresar como dato el perímetro de un cuadrado. \nCalcular e imprimir el volumen del cubo que tiene como lado el cuadrado antes mencionado. (V=a3). ");
    
    int lado, perimetro, volumen;
    
    System.out.println("Ingresar perimetro del cuadrado: ");
    perimetro = ejercicios.nextInt();
    
    lado = perimetro/4;
    
    volumen = lado*lado*lado*lado; 
    System.out.println("El volumen del cubo es: "+volumen);
    
    
    System.out.println("-----------------------------------------------------------------------------------------------------------------");
    break;
    
      case 6: System.out.println("Ejercicio6: Ingresar por teclado los precios correspondientes a cinco artículos y las cantidades vendidas de cada uno de ellos. \nCalcular e imprimir el importe total de ventas de cada uno y un importe total de lo vendido.");

    int articulos =5, precio, cantidad, importeindividual, importetotal=0;
    
    for(int i=1;i<=articulos;i++){
    System.out.println("Ingresar el precio del articulo "+i+": ");
    cantidad = ejercicios.nextInt();
    
    System.out.println("Ingresar cantidad vendida del articulo "+i+": ");
    precio = ejercicios.nextInt();
    importeindividual = precio * cantidad;
    System.out.println("EL importe total del Articulo ingresado es $: "+importeindividual);
    
    importetotal =importetotal + importeindividual;
    }
    System.out.print("La sumatoria del importe total de los 5 artículos ingredados es $: "+importetotal);
    
    System.out.println("-----------------------------------------------------------------------------------------------------------------");
    break;
    
      case 7: System.out.println("Ejercicio7: Dados los coeficientes A, B, C; de una ecuación de segundo grado, calcular e imprimir las raíces de dicha ecuación.\n- NOTA: Suponer la no existencia de raíces complejas.");
    
    int coeficienteA, coeficienteB, coeficienteC, raiz, x1, x2;
    
    System.out.println("Ingresar el coeficiente A: ");
    coeficienteA = ejercicios.nextInt();
    
    System.out.println("Ingresar el coeficiente B: ");
    coeficienteB = ejercicios.nextInt();
    
    System.out.println("Ingresar el coeficiente C: ");
    coeficienteC = ejercicios.nextInt();
    
    //la función Mart.sqrt sirve para calcular la raiz de un número y Math.pow, sirve para calcular un número elevado a una potencia.
    raiz= (int) Math.sqrt((Math.pow(coeficienteB, 2))-(4*coeficienteA*coeficienteB*coeficienteC));
    x1 = ((-coeficienteB)+raiz)/(2*coeficienteA);
    x2 = ((-coeficienteB)-raiz)/(2*coeficienteA);
   
    if (raiz<0){
        System.out.print("No existe soluciones para está ecuación");
        JOptionPane.showMessageDialog(null,"La incógnita es = "+raiz);
                
    } 
    
    if (raiz==0){
        System.out.print("Existe una única solución para este ecuación");
    
    
    } else{
        System.out.print("Existen dos posibles soluciones para esta ecuación: ");
        JOptionPane.showMessageDialog(null,"Primera solución es: "+x1);
        JOptionPane.showMessageDialog(null,"Segunda solución es: "+x2);
       }
    
    break;
            
            case 8: JOptionPane.showMessageDialog(null,"Ejercicio8: Leer desde el teclado un valor que corresponda a la distancia entre dos puntos \nexpresada en Dmts. y transformarla en Cms., Imprimirla. ");
    float punto1, punto2, distancia, distancia2;
    
    System.out.println("Ingresar la distancia del primero punto en Dmts: ");
    punto1 = ejercicios.nextFloat();
    
    System.out.println("Ingresar la distancia del segundo punto en Dmts: ");
    punto2 = ejercicios.nextFloat();
    distancia = (float) (punto1*0.01);
    distancia2 = (float) (punto2*0.01);
    
    JOptionPane.showMessageDialog(null, "La distancia del punto uno en Cms es: "+distancia+"\nLa distancia del punto dos en Cms es: "+distancia2);
           
    break;
    
            case 9: JOptionPane.showMessageDialog(null,"Ejercicio9: Teniendo como dato el tiempo transcurrido desde el inicio hasta el final de un acontecimiento cualquiera expresado en días, \nhacer los cálculos necesarios e imprimirlo en MINUTOS.  ");
    int dia, minutos;
    
    System.out.println("Ingresar la cantidad de Días del acontecimiento: ");
    dia = ejercicios.nextInt();
    
    minutos = dia*24*60;
    
    JOptionPane.showMessageDialog(null,"La cantidad de minutos de estos días transcurridos son: "+minutos);       
            case 10: 
do {
    condicional=0;
    JOptionPane.showMessageDialog(null, "Ejercicios: 10.Indicar si un número ingresado es par o impar. \n" +
"11.	Leer un número e indicar si este es múltiplo de dos. \n" +
"12.	Leer un número e indicar si el mismo es divisible por tres.");

    
      int number;     
        
    System.out.println("Ingresar un número: ");
    number = ejercicios.nextInt();
    
    if(number % 2 == 0) {
    System.out.println("EL NÚMERO INGRESADO ES UN NÚMERO PAR");
    System.out.println("ES UN NÚMERO MULTIPLO POR DOS");
    
    }else {
        System.out.println("EL NÚMERO INGRESADO ES UN NÚMERO IMPAR");
        if(number%3 == 0){
        System.out.println("EL NÚMERO INGRESADO ES DIVISIBLE POR TRES");
        } else {
        System.out.println("El número ingresado no es divisible por tres");
        }
    }
    System.out.println("Desea repetir el ejercicio número 18, SÍ [1]  NO[0]: ");
    condicional = ejercicios.nextInt();
}while(condicional != 0 );
    break;
    
            case 13:
    float np;
    
    JOptionPane.showMessageDialog(null,"Ejercicio13: Dado un número entero positivo menor que cien, leerlo desde teclado y  "
            + "indicar si es primo. (Los números primos son aquellos que sólo son divisibles por sí mismos y por uno."
            + "- En el caso del ejemplo, por ser el número leído menor que cien, sólo hay que comprobar que el número "
            + "no sea 2 - 3 - 5 - 7 o múltiple de alguno de estos. "
            + "Si se cumple esta condición, se trata entonces de un número primo. ");
    
     do { 
     np=0;  
    
    np = Float.parseFloat(JOptionPane.showInputDialog("Ingresar un número intero menor que 100: "));
    
        if(np <100){
            if(np!=2 && np!=3 && np!=5 && np!=7){
                if(np%2!=0 && np%3!=0 && np%5!=0 && np%7 !=0){
                    System.out.println("El número ingresado es un número PRIMO");
                        } else {
                
                    System.out.println("EL NÚMERO INGRASADO ES UN NÚMERO MULTIPLO DE ALGUNO DE ESTOS NÚMERO 2, 3, 5 Y 7. \n POR FAVOR INGRESE OTRO NÚMERO QUE NO SEA MULTIPLO DE ÉSTOS");
                }
            
            }else {
             JOptionPane.showMessageDialog(null, "EL NÚMERO INGRESADO NO PUEDE SER 2, 3 , 5, 7 Y TAMPOCO SUS MULTIPLOS");
                
                
            }
            
                           
        }else {
        JOptionPane.showMessageDialog(null,"ERROR, HAS INGRESADO UN NÚMERO MAYOR QUE CIEN");
        
        }
    System.out.print("DESEA REPETIR LA OPERACIÓN SÍ[0]  NO[1]: ");
     condicional=ejercicios.nextInt();
    } while(condicional == 0); 
       
    break;
    
            case 14: JOptionPane.showMessageDialog(null, "Ejercicio14: Leer dos números e imprimir el mayor, suponer que son distintos."); 
     int num, num2, mayor; 
     
     System.out.println("Ingresar un número intero: ");
     num = ejercicios.nextInt();
     
     System.out.println("Ingresar otro número intero distinto al primero: ");
     num2 = ejercicios.nextInt();
            if(num>num2){
                JOptionPane.showMessageDialog(null, "El primero número es mayor que el segudno");
            }else {
            JOptionPane.showMessageDialog(null, "El segundo número es mayor que el primero");
            }
            break;
            
            case 15: do{
    JOptionPane.showMessageDialog(null, "Ejercicio15: Leer tres números distintos e imprimir el mayor."); 
        int nu1, nu2, nu3;
        condicional = 0;
        System.out.println("Ingresar el primero número: ");
        nu1 = ejercicios.nextInt();
        
        System.out.println("Ingresar el segundo número: ");
        nu2 = ejercicios.nextInt();
        
        System.out.println("Ingresar el tercero número: ");
        nu3 = ejercicios.nextInt();
    
            if(nu1>nu2 && nu1>nu3){
            JOptionPane.showMessageDialog(null,"El mayor número es: "+nu1);
            
            }else {
                if (nu2>nu3){
                    JOptionPane.showMessageDialog(null,"El mayor número es: "+nu2);
                
                } else {
                    JOptionPane.showMessageDialog(null,"El mayor número es: "+nu3);
                }
            }
            System.out.println("Deseas Repetir el ejercicio 15, SÍ[1]  NO [0]: ");
    } while (condicional != 0);
    break;
    
            case 16: 
                do {
    condicional = 0;    
    
    JOptionPane.showMessageDialog(null, "Ejercicio16: Leer dos números, calcular e imprimir el cociente entre el mayor y el menor."); 
    int nume1, nume2, re; 
    System.out.println("Ingresar dos número: ");
    nume1 = ejercicios.nextInt();
    nume2 = ejercicios.nextInt();
   
    if(nume1>nume2){
    re = nume1/nume2;
        JOptionPane.showMessageDialog(null,"El coeciente entre en número uno que es mayor y el segundo por ser el menor es: "+re);
        } else {
        re = nume2/nume1;
            JOptionPane.showMessageDialog(null,"El cociente entre el segundo número por ser el mayor y el primero el menor es: "+re);
           }
        System.out.println("Desea repetir el ejercicio número 16, SÍ [1]  NO[0]: ");
            condicional = ejercicios.nextInt();
        }while(condicional != 0 );
    break;
        
            case 17:    do{
            
            condicional =0; 
            int nume01 =0, nume02 = 0, nume3, resu;
            
    JOptionPane.showMessageDialog(null, "Ejercicio17: Leer dos números, si el primero es el mayor, sumarlos, si no multiplicarlos, imprimir el resultado."); 
    System.out.println("Ingresar dos número: ");
    nume01 = ejercicios.nextInt();
    nume02 = ejercicios.nextInt();
    
            if(nume01>nume02){
            
            resu = nume01+nume02;
            JOptionPane.showMessageDialog(null, "COMO EL PRIMERO NÚMERO ES MAYOR, SE REALIZA LA SUMA DE ÉSTOS QUE ES: "+resu);
            } else{
                resu = nume01*nume02;
                JOptionPane.showMessageDialog(null, "COMO EL SEGUNDO NÚMERO ES MAYOR, SE REALIZA LA MULTIPLICACIÓN DE ÉSTOS QUE ES: "+resu);
              }
            
            System.out.println("Desea repetir el ejercicio número 17, SÍ [1]  NO[0]: ");
            condicional = ejercicios.nextInt();
            }while(condicional != 0);
           
            break;
            
            case 18: do {
                condicional = 0;
            JOptionPane.showMessageDialog(null, "Ejercicio18: Leer tres números y sumarlos, si la suma es mayor que 10, calcular la raíz cuadrada"
                    + "\nde la suma e imprimirla, de lo contrario, leer dos números más y sumarlos junto a los primeros, luego imprimir la suma.");
            int numero01, numero02, numero03, numero04, numero05, totals, raizs;
            System.out.println("Ingresar tres números: ");
            numero01 = ejercicios.nextInt();
            numero02 = ejercicios.nextInt();
            numero03 = ejercicios.nextInt();
            
            totals = numero01 + numero02 + numero03;
            
            if(totals>10){
                raiz = (int) Math.sqrt(totals);
            JOptionPane.showMessageDialog(null,"LA RAIZ DE LA SUMA DE LOS TRES NÚMEROS ES: "+raiz);
            } else{
            System.out.println("Ingresar dos número más: ");
            numero04 = ejercicios.nextInt();
            numero05 = ejercicios.nextInt();
                
            totals = numero01 + numero02 + numero03 + numero04 + numero05;
            JOptionPane.showMessageDialog(null,"LA SUMA DE LOS CINCO NÚMEROS INGRESADOS ES: "+totals);
            }
            System.out.println("Desea repetir el ejercicio número 18, SÍ [1]  NO[0]: ");
            condicional = ejercicios.nextInt();
            }while(condicional != 0 );
            break;
            
            case 19: do {
            condicional = 0;    
            
        JOptionPane.showMessageDialog(null, "Ejercicio19: Dados los tres lados de un triángulo, informar si se trata de un triángulo equilátero, isósceles o escaleno.");
            int lado1, lado2, lado3;
    
            System.out.println("Ingresar tres lados de un triángulo: ");
            lado1 = ejercicios.nextInt();
            lado2 = ejercicios.nextInt();
            lado3 = ejercicios.nextInt();
            
            if (lado1 == lado2 && lado1 == lado3){        
                JOptionPane.showMessageDialog(null,"El triángulo es EQUILATERO");
            
            }else{
                    if(lado1 == lado2 || lado1 == lado3){
                    JOptionPane.showMessageDialog(null,"El triángulo es ISÓSCELES");
                    
                    } else {
                    JOptionPane.showMessageDialog(null,"El triángulo es ESCALENO");
                    
                    }
            
                }
            
            System.out.println("Desea repetir el ejercicio número 19, SÍ [1]  NO[0]: ");
            condicional = ejercicios.nextInt();
            } while(condicional != 0);
            
            break;
            
            case 20: do {
            condicional=0;
            
                JOptionPane.showMessageDialog(null, "Ejercicio20: Leer dos números e indicar mediante un mensaje si la suma es mayor que setecientos treinta ");
                int numero06, numero07, totalsuma; 
            
                System.out.println("Ingresar dos números: ");
                numero06 = ejercicios.nextInt();
                numero07 = ejercicios.nextInt();
                
                totalsuma = numero06 + numero07;
                if(totalsuma > 730){
                    JOptionPane.showMessageDialog(null,"LA SUMA DE LOS DOS NÚMEROS SUPERA LOS 730 Y EL RESULTADO ES: "+totalsuma);
                
                }else {
                    JOptionPane.showMessageDialog(null,"LA SUMA DE LOS DOS NÚMEROS NO SUPERA LOS 730 Y EL RESULTADO ES : "+totalsuma);
                }
            System.out.println("Desea repetir el ejercicio número 20, SÍ [1]  NO[0]: ");
            condicional = ejercicios.nextInt();
            } while(condicional != 0);
            break;
            
            case 21: do {
                condicional = 0;
                
            JOptionPane.showMessageDialog(null, "Ejercicio21: Leer la base y la altura de un rectángulo, calcular e imprimir el perímetro del rectángulo, "
                    + "\ninformando además si se trata esta figura de un cuadrado (los cuatro lados iguales).");
            int ladob, ladoh, perimetror=0;
            
                  System.out.print("Ingresar base: ");
                  ladob = ejercicios.nextInt();
                  
                  System.out.print("Ingresar altura: ");
                  ladoh = ejercicios.nextInt();
                  
                  if(ladob != ladoh){
                      perimetror = (ladob+ladoh)*2;
                      JOptionPane.showMessageDialog(null, "Los números ingresados se trata de un rectángulo y su perimetro es: "+perimetror);
                  
                    }else {
                        JOptionPane.showMessageDialog(null, "Los números ingresados se trata cuadrado y su perimetro es: "+perimetror);
                    
                        }
            
            
            System.out.println("Desea repetir el ejercicio número 21, SÍ [1]  NO[0]: ");
            condicional = ejercicios.nextInt();
            } while(condicional != 0);
            
            break;
            
            case 22: do{    
            JOptionPane.showMessageDialog(null, "Ejercicio22: Leer cuatro números distintos e imprimirlos en orden ascendente");
            
            int [] vector = new int[4]; 
   
            for(int j=0; j<vector.length;j++){

                System.out.println("Ingresar un número: ");
                vector[j] = ejercicios.nextInt();

            }

            Arrays.sort(vector);
            //Es una función de la libreria "import java.util.Arrays" que ordena los números de un arreglo de forma ascendente.

            JOptionPane.showMessageDialog(null,"Los elementos ordenados del vector/Array son: "+Arrays.toString(vector));
            //Arrays.toString() te imprime todos los elementos de un vector que pases como parametro.

            System.out.println("Desea repetir el ejercicio número 21, SÍ [1]  NO[0]: ");
                    condicional = ejercicios.nextInt();
              } while(condicional != 0);
        break;
        
            case 23: 
            
                
                break;
        
            default: //JOptionPane.showMessageDialog(null,"PERDÓN, EL NÚMERO DE EJERCICIO NO EXISTE");
                    break;
  }

}
    } 