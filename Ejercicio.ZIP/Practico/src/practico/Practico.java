
package practico;


public class Practico {

   
    public static void main(String[] args) {
   
  
    }
}